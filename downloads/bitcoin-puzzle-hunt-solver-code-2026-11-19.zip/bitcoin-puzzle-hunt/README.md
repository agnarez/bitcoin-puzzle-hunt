# Bitcoin Puzzle Hunt — Pubkey-Exposed Only (#140, #145, #150, #155, #160)

Hunter: agnarez. Assistant: Muse.
Strategy: **Reversed/backwards scanning · Centre-Out from 25% ·
Front 50% Only · Pubkey-Exposed Only.**

75 BTC combined (14 + 14.5 + 15 + 15.5 + 16). All five still unsolved
as of 10 Nov 2026. Research: `~/workspace/research_notes/bitcoin-puzzle-hunt-research-20261110-1408/report.md`.

## HARD RULE — locked in, everywhere

- If a private key is found, it goes **ONLY to agnarez privately, in
  the main chat**. Never to anyone else.
- The public website will **NEVER** carry a private key — not before
  claiming, not after, not ever. It can only announce
  `SOLVED — puzzle #, date, ops searched` with no key.
- The daily report + website-update job follows the same rule.
- The solver enforces this: on a find it prints only
  `FOUND puzzle #N` to stdout and writes the key only to
  `private/FOUND-PRIVATE.txt`. No log, checkpoint, progress file, or
  website build ever contains a key. That file is never included in
  any website build.

## Targets

| # | Address | Prize | Range |
|---|---|---|---|
| 140 | `1QKBaU6WAeycb3DbKbLBkX7vJiaS8r42Xo` | 14 BTC | `[2^139, 2^140)` |
| 145 | `19GpszRNUej5yYqxXoLnbZWKew3KdVLkXg` | 14.5 BTC | `[2^144, 2^145)` |
| 150 | `1MUJSJYtGPVGkBCTqGspnxyHahpt5Te8jy` | 15 BTC | `[2^149, 2^150)` |
| 155 | `1AoeP37TmHdFh8uN72fu9AqgtLrUwcv2wJ` | 15.5 BTC | `[2^154, 2^155)` |
| 160 | `1NBC8uXJy1GiJ6drkiZa1WuKn51ps7EPTv` | 16 BTC | `[2^159, 2^160)` |

Full pubkeys, hex ranges, front-50% windows, centre-25% and midpoint
values: `data/puzzles.json`. Method and maths: `docs/METHOD.md`.

## Honest limits of this VM

This VM is **1.5 shared CPU, no GPU**. Measured here (see Smoke test
below): Python Kangaroo ~a few thousand ops/s, Python sequential scan
~a few thousand keys/s, C scanner ~10^5 keys/s. #140 needs ~2^69.5
Kangaroo ops — ~5.7× the work of #135, which took ~5 months on
200 GPUs. **Nothing on this VM can solve #140 in any realistic time.**
What is built here is: correct, checkpointed, resumable engines that
are ready to run on a GPU rig, plus exact GPU configs for the tools
that *can* scale (RCKangaroo, JLP Kangaroo / Kangaroo-256, KeyHunt,
collider, Coin Cracker). Front-50% / centre-out / reversed do not
change expected Kangaroo work if keys are uniform (40 front / 43 back
among the 83 solved keys) — they only change which keys would be found
early. See `docs/METHOD.md` §4.

## Layout

```
data/puzzles.json    5 verified targets (address, pubkey, ranges)
data/progress.json   ops searched / ranges covered / status (no keys, ever)
solver/secp256k1.py  pure-Python secp256k1 (Jacobian), pubkey/address checks
solver/kangaroo.py   Pollard Kangaroo, distinguished points, checkpoints
solver/bsgs.py       Baby-step giant-step, small intervals only (refuses large)
solver/reversed_scan.py  sequential forward/reversed/centre-out/midpoint scanner
solver/run_hunt.py   orchestrator + FOUND handling (hard rule)
solver/rckangaroo_gen.py  generates GPU configs in solver/generated/
solver/generated/    RCKangaroo / JLP / KeyHunt / collider / Coin Cracker inputs
solver/c_scan.c + Makefile  fast C sequential scanner (OpenSSL EC)
docs/METHOD.md       design, maths, honest odds, risks/claiming
```

## How to run (CPU, this VM)

```bash
cd ~/workspace/bitcoin-puzzle-hunt/solver

# Kangaroo, centre-out, front-50% window, puzzle #140, 1M ops (bounded test)
python3 run_hunt.py --puzzle 140 --method kangaroo-centre-out --max-ops 1000000

# Sequential centre-out scan, front-50% window, 1M keys
python3 run_hunt.py --puzzle 140 --method scan-centre-out --max-ops 1000000

# Reversed Kangaroo, full range
python3 run_hunt.py --puzzle 140 --method kangaroo-reversed --window full --max-ops 1000000

# Midpoint variant (xlh6), sequential
python3 run_hunt.py --puzzle 140 --method scan-midpoint --max-ops 1000000

# C scanner (build first: make), small range example
make
./c_scan --pubkey 031f6a332d3c5c4f2de2378c012f429cd109ba07d69690c6c701b6bb87860d6640 \
  --start 80000000000000000000000000000000000 \
  --end   80000000000000000000000000000000000 --max-keys 1
```

Progress is recorded in `data/progress.json` after every run.
Checkpoints land in `logs/`.

## How to use the GPU configs (the real engine)

```bash
cd solver && python3 rckangaroo_gen.py   # (re)generates solver/generated/
```

See `solver/generated/README.md`. On a CUDA rig, start with
`rckangaroo-140-front50.sh` — RCKangaroo, front-50% window, the hunt
scope. JLP Kangaroo cannot take a 138-bit window (125-bit limit):
use the generated ≤125-bit chunk files, or the Kangaroo-256 fork with
`jlp-kangaroo-140-front50-full.txt`.

## Smoke test

```bash
cd solver && python3 test_smoke.py
```

Picks a known key in a small 28-bit range, computes its pubkey, and
confirms Kangaroo, BSGS, reversed scan, and `run_hunt.py` each find it
— and that no key leaks into `progress.json` or logs. Also run:
`python3 -m py_compile secp256k1.py kangaroo.py bsgs.py reversed_scan.py run_hunt.py rckangaroo_gen.py test_smoke.py`
and `make` in `solver/`.

## Claiming (if a key is ever found)

1. The key is delivered to agnarez privately in the main chat only.
2. Do NOT broadcast a spend to the public mempool.
3. Submit directly to a miner / private relay (e.g. MARA Slipstream).
4. Only after the funds are confirmed moved may the public site say
   `SOLVED — puzzle #, date, ops searched` — still with no key, ever.
