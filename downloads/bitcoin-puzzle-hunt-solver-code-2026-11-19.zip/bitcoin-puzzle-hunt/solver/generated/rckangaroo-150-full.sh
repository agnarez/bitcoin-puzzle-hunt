# RCKangaroo — puzzle #150, FULL range (for reference; front-50% is the hunt scope)
RCKangaroo -dp 16 -range 149 -start 20000000000000000000000000000000000000 -pubkey 03137807790ea7dc6e97901c2bc87411f45ed74a5629315c4e4b03a0a102250c49
